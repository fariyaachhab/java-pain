public class Baccarat {
  // TODO: Implement your Baccarat simulation program here
}
