// TODO: Implement the Shoe class in this file
