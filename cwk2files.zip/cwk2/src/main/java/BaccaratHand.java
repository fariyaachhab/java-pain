// TODO: Implement the BaccaratHand class in the file
