// TODO: Implement the BaccaratCard class in this file
